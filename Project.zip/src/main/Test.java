package main;

import ui.UI;

public class Test {

	public static void main(String[] args) {

		UI ui = new UI("Hàm tính các tham số k");
		ui.showWindows();
	}

}
