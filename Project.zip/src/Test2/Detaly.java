package Test2;

import java.util.ArrayList;

public class Detaly {
	public double detaly(double[] x,double[] y,String sMath,double[]k){
		String temp,elementMath[]=null;
		InfixToPostfix  IFP = new InfixToPostfix();
		sMath = IFP.processString(sMath);
        elementMath = sMath.split(" ");
        temp = sMath = IFP.postfix(elementMath);  //  dua cac phan tu ve dang postfix
        double detaly =0;
        double yTB =0;
        for(int i=0;i<y.length;i++){
        /*sMath = IFP.replaceXYK(temp,x[i],k);*/
        elementMath = sMath.split(" ");
        double a=IFP.EvaluatePostfix(elementMath, x[i], k);
        detaly = detaly + Math.abs(y[i]-a);
        }
        detaly =detaly/y.length;
        for (int i = 0; i < y.length; i++) {
			yTB += y[i];
		}
        yTB =yTB / y.length ;
        detaly =Math.abs(detaly/yTB) ;
        return detaly;
	}
}
