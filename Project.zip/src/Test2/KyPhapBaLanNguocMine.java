package Test2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.Stack;

import javax.swing.text.GapContent;

import Test2.HamGA;
public class KyPhapBaLanNguocMine{
	private final String className = "com.mysql.jdbc.Driver";
	private final String url = "jdbc:mysql://localhost:3306/project_1";
	private final String user = "root";
	private final String password = "";
	private String table1 = "parameters_2";
	private String table2 = "reference_relation";
	
	private Connection connection;
	
	public static List<Double> dsX = new ArrayList<Double>();
	public static ArrayList<ArrayList<List<Double>>> tapGiaTriXY = new ArrayList<ArrayList<List<Double>>>();
	public static List<String> tapBieuThuc = new ArrayList<String>() ;
	private void connect()
	{
		try 
		{
			Class.forName(className);
			connection =  DriverManager.getConnection(url, user, password);
			System.out.println("Connect success");
			
		} catch (ClassNotFoundException e) 
		{
			System.out.println("Class not found");
			
		} catch (SQLException e) 
		{
			System.out.println("Error Connect");
		}
		
	}
	
	public void xayDungCacTapGiaTri()
	{
		ResultSet rs = null;
		String sqlCommand = "select * from " + table1; // Lấy dữ liệu từ bảng parameter
		//java.sql.Statement st  ;
		
		try {
			java.sql.Statement st = connection.createStatement();
			rs= st.executeQuery(sqlCommand);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		ArrayList<List<Double>> tapCacCapGiaTriXYUngVoiMoiBieuThuc = new ArrayList<List<Double>>();
		int bieuThucTuongUng = 1;
		
		try {
			while (rs.next()) {
				List<Double> capGiaTriXY = new ArrayList<Double>();
				capGiaTriXY.add(rs.getDouble(3));
				capGiaTriXY.add(rs.getDouble(4));
				if (rs.getInt(2) == bieuThucTuongUng) {
					tapCacCapGiaTriXYUngVoiMoiBieuThuc.add(capGiaTriXY);
				}else{
					tapGiaTriXY.add(tapCacCapGiaTriXYUngVoiMoiBieuThuc);
					bieuThucTuongUng = rs.getInt(2);
					tapCacCapGiaTriXYUngVoiMoiBieuThuc = new ArrayList<List<Double>>();
					tapCacCapGiaTriXYUngVoiMoiBieuThuc.add(capGiaTriXY);
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		ResultSet rs2 = null;
		String sqlCommand2 = "select * from " + table2; // Lấy dữ liệu từ bảng reference_relation
		//java.sql.Statement st  ;
		
		try {
			java.sql.Statement st = connection.createStatement();
			rs2= st.executeQuery(sqlCommand2);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			while (rs2.next()) {
				tapBieuThuc.add(rs2.getString(2));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	

	
	public void showData ()
	{
		for (int i = 0; i < tapGiaTriXY.size(); i++) {
			System.out.printf("\n\n" + tapBieuThuc.get(i));
			for (int j = 0; j < tapGiaTriXY.get(i).size(); j++) {
				System.out.print("\n" + tapGiaTriXY.get(i).get(j).get(0) + " - " + tapGiaTriXY.get(i).get(j).get(1));
			}
		}
	}
	
	public static void main(String[] agrs){
		/*KyPhapBaLanNguocMine kyPhapBaLanNguocMine = new KyPhapBaLanNguocMine();
		kyPhapBaLanNguocMine.connect();
		kyPhapBaLanNguocMine.xayDungCacTapGiaTri();
		kyPhapBaLanNguocMine.showData();
		
		System.out.println("\n\nNhập biểu thức: \n");
        String sMath="";
       
        double[] x = {0.0861,0.1084,0.125,0.138};
        double[] y={1.1,2.3,3.4,3.6};
        double[] k ={0.5,2,3};
        Scanner input = new Scanner(System.in);
        sMath = input.nextLine(); 
        
        Detaly tinh = new Detaly();
        double c = tinh.detaly(x, y, sMath, k);
        System.out.println("Giá trị detal yTB = \n"+c);
       
       HamGA GA = new HamGA(x, y, 0.6, 0.2, 30, 50000000, 0.2);
       // double[]boThamSo;
        ArrayList<double[]>boThamSo;
        boThamSo=GA.GAs(sMath);
        System.out.println("Giá trị của các tham số");
        for(int i=0;i<boThamSo.size();i++)
        {
        	//System.out.println("\n"+boThamSo[i]);
        	System.out.println("\n"+boThamSo.get(i)[0]);
        }
        double uutientest = (double)(1 - 1.0/(1+tinh.detaly(x, y,sMath,boThamSo.get(0))));	
        System.out.printf("\n do uu tien[0] = " + uutientest);
        input.close();
        //k_{1}*x+k_{2}*(e^(-k_{3}*x)-1)
*/    }
	

}