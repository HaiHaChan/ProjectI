package Test2;

import java.util.Arrays;
import java.util.Stack;

public class InfixToPostfix {

	public int priority(char c)//thiết lập độ ưu tiên
	{
		if(c=='+' || c=='-' ) return 1;
		else if(c=='*'||c=='/') return 2;
		else if(c=='^'||c=='s') return 3;
		else if(c=='l'|| c=='o' || c=='a') return 4;
		else return 0;	
	}
	public static boolean isOperator(char c){  // kiem tra xem co phai toan tu
		char operator[] = { '+', '-', '*', '/', '^',')', '(','l','s','o','a'};
		Arrays.sort(operator);
		if (Arrays.binarySearch(operator, c) > -1)
			return true;
		else return false;
	}   
	public String processString(String sMath){ // xu ly bieu thuc nhap vao thanh cac phan tu
		String s1 = "", elementMath[] = null;
		InfixToPostfix  IFP = new InfixToPostfix();
		sMath = sMath.trim();
		sMath = sMath.replace(" ","");//  chuan hoa sMath
		if (sMath.charAt(0) == '-') sMath = "0" + sMath;
		sMath = sMath.replace("sqrt","s");
		sMath = sMath.replace("ln","l");
		sMath = sMath.replace("log","o");
		sMath = sMath.replace("arctan","a");
		sMath = sMath.replace("(-","(0-");
		for (int i=0; i<sMath.length(); i++){
			char c = sMath.charAt(i);//sMath.substring(i,1)
			if (!IFP.isOperator(c))
				s1 = s1 + c;
			else if(i>0 && IFP.isOperator(sMath.charAt(i-1)))
				s1 = s1 + c+" ";
			else 
				s1=s1+" "+c+" ";
		}
		s1 = s1.trim();
		s1 = s1.replace("s","sqrt");
		s1 = s1.replace("l","ln");
		s1 = s1.replace("o","log");
		s1 = s1.replace("a","arctan");
		//elementMath = s1.split(" "); //tach s1 thanh cac phan tu
		//for (int i=0; i<elementMath.length; i++){System.out.println("*" + elementMath[i]);}     
		return s1;

	}
	public String postfix(String[] elementMath){
		InfixToPostfix  IFP = new InfixToPostfix();
		String s1 = "";
		Stack<String> S = new Stack<String>();
		for (int i=0; i<elementMath.length; i++){    // duyet cac phan tu
			char c = elementMath[i].charAt(0);
			if (!IFP.isOperator(c))  // neu c khong la toan tu
			{
				if(s1=="") 
					s1= s1+elementMath[i];
				else
					s1 = s1 + " " + elementMath[i];     // xuat elem vao s1
			}
			else{                       // c la toan tu
				if (c == '(') 
					S.push(elementMath[i]);   // c la "(" -> day phan tu vao Stack
				else if (c == ')'){          // c la ")"
					char c1;        //duyet lai cac phan tu trong Stack
					do{
						c1 = S.peek().charAt(0);    // c1 la ky tu dau tien cua phan tu
						if (c1 != '(') s1 = s1 + " " + S.peek();    // trong khi c1 != "("
						S.pop();
					}while (c1 != '(');
				}else{
					while (!S.isEmpty() && ((IFP.priority(S.peek().charAt(0)) > IFP.priority(c)) ||
							((IFP.priority(S.peek().charAt(0)) == IFP.priority(c)) && (c != '^')))){
						// Stack khong rong va trong khi phan tu trong Stack co do uu tien >= phan tu hien tai
						s1 = s1 + " " + S.peek();   // xuat phan tu trong Stack ra s1
						S.pop();
					}
					S.push(elementMath[i]); //  dua phan tu hien tai vao Stack
				}

			}
		}
		while (!S.isEmpty()){   // Neu Stack con phan tu thi day het vao s1
			s1 = s1 + " " + S.peek();
			S.pop();
		}
		//E = s1.split(" ");  //  tach s1 thanh cac phan tu
		return s1;
	}
	/*public String replaceXYK(String s,double x,double[] k){
        s = s.replaceAll("x", String.valueOf(x));
        for(int i = 0; i< 3; i++){
            s = s.replaceAll("k"+i,String.valueOf(k[i]));
        }
        return s;
    }*/

	public static Double EvaluatePostfix(String[] elementMath, double a, double[] k)//ham tinh gia tri bieu thuc
	{
		Stack<Double> s = new Stack<Double> ();
		for(int i=0;i<elementMath.length;i++)
		{
			elementMath[i]=elementMath[i].replace("log","o");
			char c = elementMath[i].charAt(0);
			if (!isOperator(c))
			{
				double m=0.0;
				if(c=='e') {
					m=(double)Math.E;
				}
				else if(c=='x') {
					m=a;
				}

				else if(elementMath[i].equals("k_{1}")  == true) {
					m=(double)k[0];
				}
				else if(elementMath[i].equals("k_{2}")  == true) {
					m=(double)k[1];
				}
				else if(elementMath[i].equals("k_{3}")  == true) {
					m=(double)k[2];
				}
				else if(c=='k') {
					m=(double)k[0];
				}
				else {
					m = Double.parseDouble(elementMath[i]);
				}
				// Double Object
				s.push(m);
			}
			else
			{
				double x = s.pop();
				double y=0.0;
				switch (c)
				{
				case '+': y = s.pop();x += y; 
				break;
				case '-': y = s.pop();x = y-x; 
				break;
				case '*': y = s.pop();
				x *= y; 
				break;
				case '/':
				{
					/*if(x==0)return 10000000.0;*/
					y = s.pop();x = y/x; 
					break;
				}
				case '^': 
				{

					y = s.pop();
					if(x==0.5||x==1.5)
						if(y<0) return 10000000000.0;
					if(y>2&&x>30) return 1000000000000000.0;

					if(y<0 &&x == (double)2/3) 
						x = (double) Math.pow(-y,(double)x);
					else if(y<0&& x == (double)1/3)
						x = (double) (Math.pow(-y,(double)x)*(-1));
					else if(y<0 && (x-(int)x ) >0){
						return 100000.0;
					}
					else 
						x = (double) Math.pow(y, (double)x);


					break;
				}
				case 's': x=(double)Math.sqrt(x);
				break;
				case 'l': x=(double)Math.log(x);
				break;
				case 'o':
				{
					if(x<0) return 10000.0;
					x=(double)Math.log10(x);
					break;
				}
				case 'a': x=(double)Math.atan(x) * (double)180/Math.PI;
				}
				s.push(x);

			}
		}
		return s.pop();
	}
}


