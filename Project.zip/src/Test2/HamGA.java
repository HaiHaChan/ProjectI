package Test2;

import java.lang.reflect.Array;
import java.time.chrono.ChronoLocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.swing.text.StyleContext.SmallAttributeSet;

import Test2.Detaly;

public class HamGA {

	private double[] x;
	private double[] y;
	double r;//Xác xuât lai ghép
	double w;//Xác xuất đột biến
	double l;//độ ưu tiên mong muốn
	int n;//Số lượng cá thể trong quần thể
	int m;/*Số lượng lần lặp mong muốn trong trường hợp chưa thỏa mãn 
	độ ưu tiên mong muốn*/
	ArrayList<double[]> dsBoThamSoLuu1000 = new ArrayList<double[]>();
	List<Integer> dsGiaTriRandom = new ArrayList<Integer>();  
	int ll;
	
	public HamGA(double[] x, double[] y,
			double r, double l, int n, int m, double w) {
		super();
		this.x = x;
		this.y = y;
		this.r = r;
		this.l = l;
		this.n = n;
		this.m = m;
		this.w = w;
		
		for (int i = 0; i < 50; i++) {
			dsGiaTriRandom.add(10000);
		}
		dsGiaTriRandom.set(3, 10);
		dsGiaTriRandom.set(5, 10);
		dsGiaTriRandom.set(7, 100);
		dsGiaTriRandom.set(8, 1);
		dsGiaTriRandom.set(13, 10);
		dsGiaTriRandom.set(14, 1000);
		dsGiaTriRandom.set(16, 1000);
		dsGiaTriRandom.set(18, 150000);
		dsGiaTriRandom.set(19, 1);
		dsGiaTriRandom.set(20, 10000);
		dsGiaTriRandom.set(21, 1000000);
		dsGiaTriRandom.set(22, 900000000);
		dsGiaTriRandom.set(24, 1);
		dsGiaTriRandom.set(25, 100000);
		dsGiaTriRandom.set(26, 1);
		dsGiaTriRandom.set(27, 10);
		dsGiaTriRandom.set(28, 100);
		dsGiaTriRandom.set(30, 900000000);
		dsGiaTriRandom.set(33, 1000);
		dsGiaTriRandom.set(31,10);
		dsGiaTriRandom.set(34, 1);
		dsGiaTriRandom.set(36, 5);
		dsGiaTriRandom.set(39, 150);
		dsGiaTriRandom.set(40, 100);
		dsGiaTriRandom.set(41, 100);
		dsGiaTriRandom.set(42, 1);
		dsGiaTriRandom.set(44, 300000);
		dsGiaTriRandom.set(47, 1);
		dsGiaTriRandom.set(48, 100);
	}
	
	
	public List<Integer> getDsGiaTriRandom() {
		return dsGiaTriRandom;
	}


	public void setDsGiaTriRandom() {
		
	}


	public double getW() {
		return w;
	}
	public void setW(double w) {
		this.w = w;
	}
	public HamGA() {
		this.x = null;
		this.y = null;
		this.r = 0.5;
		this.l = 0.1;
		this.n = 30;
		this.m = 0;
		this.w = 0.1;
	}
	public int getM() {
		return m;
	}
	public void setM(int m) {
		this.m = m;
	}

	public double[] getX() {
		return x;
	}
	public void setX(double[] x) {
		this.x = x;
	}
	public double[] getY() {
		return y;
	}
	public void setY(double[] y) {
		this.y = y;
	}
	public double getR() {
		return r;
	}
	public void setR(double r) {
		this.r = r;
	}
	public double getL() {
		return l;
	}
	public void setL(double l) {
		this.l = l;
	}
	public int getN() {
		return n;
	}
	public void setN(int n) {
		this.n = n;
	}


	// Phương thức trả về------------------------------------------------------------
	public ArrayList<double[]> GAs(String sMath, int row){
		int soThamSo = TinhSoThamSo(sMath);
		ArrayList<double[]> dsBoThamSo = new ArrayList<double[]>();
		double[]uuTien ;
		Random ranint = new Random();
		uuTien = new double[n];
		int giaTriRandom = dsGiaTriRandom.get(row);
		for(int i=0;i<n;++i)// Khởi tạo quần thể.
		{
			double boThamSo[] = new double[soThamSo];
			for(int j=0;j<soThamSo;++j)
			{
				double ranfloat = (double)ranint.nextInt(giaTriRandom)-(double)giaTriRandom/2+ (double)ranint.nextInt(10)/10 + (double)ranint.nextInt(10)/100 + (double)ranint.nextInt(10)/1000
						 + (double)ranint.nextInt(10)/10000  + (double)ranint.nextInt(10)/100000  + (double)ranint.nextInt(10)/1000000  + (double)ranint.nextInt(10)/10000000;
				boThamSo[j] = ranfloat;
			}
			dsBoThamSo.add(boThamSo);
			Detaly tinh = new Detaly();
			//double uu = 1 - 1.0/(1+tinh.detaly(x, y, sMath, dsBoThamSo.get(i)));// Thứ tự ưu tiên Gọi hàm để tính độ ưu tiên
			double uu = tinh.detaly(x, y, sMath, dsBoThamSo.get(i));
			uuTien[i]=uu;// Thứ tự ưu tiên	
		}
		
		sapXepDanhSachBoThamSoTheoDoUuTien(uuTien,dsBoThamSo);
		int lap = 0;
		while(uuTien[0]>l && lap <m)
		{
			System.out.println(uuTien[0]);
			if(lap==10||lap==20||lap==30||lap==40)
			{
				double boThamSoLuu1000[] = new double[soThamSo];
				for(int j=0;j<soThamSo;++j)
				{
					boThamSoLuu1000[j] = dsBoThamSo.get(0)[j];
				}
				dsBoThamSoLuu1000.add(boThamSoLuu1000);
			}
			/*for(int j=0;j<soThamSo;++j)
			{
				dsBoThamSoLuu1000.add(dsBoThamSo.get(j));
			}*/
			
			laiGhep(dsBoThamSo, soThamSo);
			uuTien = new double[dsBoThamSo.size()];
			chonLoc(dsBoThamSo,sMath,uuTien);
			dotBien(dsBoThamSo, soThamSo);
			uuTien = new double[dsBoThamSo.size()];
			chonLoc(dsBoThamSo,sMath,uuTien);
			lap++;//Tăng số lần lặp
			

		}
		//return dsBoThamSo.get(0);
		return dsBoThamSo;
	}



	private int TinhSoThamSo(String sMath) {
		int k = 0;
		for (int i = 0; i < sMath.length(); i++) {
			if (sMath.charAt(i) == 'k') {
				k++;
			}
		}
		return k;
	}
	private void chonLoc(ArrayList<double[]>dsBoThamSo,String sMath,double[]uuTien0) {

		int kichThuoc= dsBoThamSo.size();

	/*	double uuTienChonLoc[]= new double[kichThuoc];*/

		for(int i=0;i<kichThuoc;++i)// Khởi tạo quần thể.
		{
			double uuChonLoc = uuChonLoc(x,y,sMath,dsBoThamSo,i);
			/*uuTienChonLoc[i]=uuChonLoc;// Thứ tự ưu tiên*/
			uuTien0[i]=uuChonLoc;
			}
		sapXepDanhSachBoThamSoTheoDoUuTien(uuTien0,dsBoThamSo);

		if(kichThuoc>n)

			for(int i=kichThuoc;i>n;--i)
			{
				dsBoThamSo.remove(i-1);
			}

	}

	private double uuChonLoc(double[] x2, double[] y2, String sMath, ArrayList<double[]> dsBoThamSo, int i) {
		Detaly tinhChonLoc = new Detaly();
		//double giatri = 1 - 1.0/(1+tinhChonLoc.detaly(x, y,sMath,dsBoThamSo.get(i)));		
		
		double uu = tinhChonLoc.detaly(x, y, sMath, dsBoThamSo.get(i));
		return uu;
	}
	private void dotBien(ArrayList<double[]> dsBoThamSo, int soThamSo) {
		double ranDotBien;
		int ranViTriDotBien;
		Random ran = new Random();
		double boThamSo[] = new double[soThamSo];
		/*for(int i=0;i<dsBoThamSo.size();++i)
		{
			ranDotBien = ran.nextDouble();
			ranViTriDotBien = ran.nextInt(3);
			if(ranDotBien<=w)
			{
				dsBoThamSo.get(i)[ranViTriDotBien]=dsBoThamSo.get(i)[ranViTriDotBien]
						+ ranDotBien*dsBoThamSo.get(i)[ranViTriDotBien];
			}
		}	*/
		for(int i=0;i<dsBoThamSo.size();++i)
		{
			if (i>=(int)(dsBoThamSo.size()*(1-w))) {
				ranDotBien = (ran.nextInt(2)+8)/10;
				ranViTriDotBien = ran.nextInt(soThamSo);
				if (ran.nextInt(10) % 2 == 0) {
					dsBoThamSo.get(i)[ranViTriDotBien]=dsBoThamSo.get(i)[ranViTriDotBien]
							+ ranDotBien*dsBoThamSo.get(i)[ranViTriDotBien];
					/*boThamSo = dsBoThamSo.get(i);
					boThamSo[ranViTriDotBien]=dsBoThamSo.get(i)[ranViTriDotBien]
							+ ranDotBien*dsBoThamSo.get(i)[ranViTriDotBien];
					dsBoThamSo.add(boThamSo);*/
				}else{
					dsBoThamSo.get(i)[ranViTriDotBien]=dsBoThamSo.get(i)[ranViTriDotBien]
							- ranDotBien*dsBoThamSo.get(i)[ranViTriDotBien];
					/*boThamSo = dsBoThamSo.get(i);
					boThamSo[ranViTriDotBien]=dsBoThamSo.get(i)[ranViTriDotBien]
							- ranDotBien*dsBoThamSo.get(i)[ranViTriDotBien];
					dsBoThamSo.add(boThamSo);*/
				}
				/*if (ran.nextInt(10) % 2 == 0) {
					boThamSo = dsBoThamSo.get(i);
					boThamSo[ranViTriDotBien]= ranDotBien*dsBoThamSo.get(i)[ranViTriDotBien];
					dsBoThamSo.add(boThamSo);
				}else{
					boThamSo = dsBoThamSo.get(i);
					boThamSo[ranViTriDotBien]= dsBoThamSo.get(i)[ranViTriDotBien]/ranDotBien;
					dsBoThamSo.add(boThamSo);
				}*/
			}else{
				break;
			}

		}	
	}
	private void laiGhep(ArrayList<double[]>dsBoThamSo, int soThamSo) {
		/*Lấy ra theo xác xuất các bộ k  -------------*/
		ArrayList<Integer> dsViTriLaiGhep = new ArrayList<Integer>();
		Random ran= new Random();
		int viTriLaiGhep1;
		int viTriLaiGhep2;
		int viTriNSTLaiGhep;
		double phanTucon;
		//double ranLaiGhep;
		int ranLaiGhep;
		int viTriLaiGhepThem;
		int soCaTheLaiGhep = 0;
		/*for(int i=0;i<n;++i)
		{

			ranLaiGhep = ran.nextDouble();
			if(ranLaiGhep<=r)
			{
				dsViTriLaiGhep.add(i);
				soCaTheLaiGhep++;
			}
		}*/

		/*for(int i=(int)(n*r);i<n;++i)
		{
			dsViTriLaiGhep.add(i);
			soCaTheLaiGhep++;	
		}*/
		for(int i=0; i< n;++i)
		{

			ranLaiGhep = ran.nextInt(n);
			if (dsViTriLaiGhep.size() == 0) {
				dsViTriLaiGhep.add(ranLaiGhep);
				soCaTheLaiGhep++;
			}else{
				for (int j = 0; j < dsViTriLaiGhep.size(); j++) {
					if (ranLaiGhep == dsViTriLaiGhep.get(j)) {
						break;
					}
					if (j == dsViTriLaiGhep.size()-1) {
						dsViTriLaiGhep.add(ranLaiGhep);
						soCaTheLaiGhep++;
					}
				}
			}
		}
		if(soCaTheLaiGhep!=0)
		{
			if(soCaTheLaiGhep%2 != 0){
				while(true)
				{
					viTriLaiGhepThem = ran.nextInt(n);
					int bienDemViTri=0;
					for(int i=0;i<soCaTheLaiGhep;++i)
					{
						if(viTriLaiGhepThem!=dsViTriLaiGhep.get(i))
							bienDemViTri++;
					}
					if(bienDemViTri==soCaTheLaiGhep)
						break;
				}
				soCaTheLaiGhep++;
				dsViTriLaiGhep.add(viTriLaiGhepThem);

			}
			//Lai Ghép các bộ k được lấy ra
			while(soCaTheLaiGhep>0)
			{
				while(true)
				{
					viTriLaiGhep1 = ran.nextInt(soCaTheLaiGhep);
					viTriLaiGhep2 = ran.nextInt(soCaTheLaiGhep);
					if(viTriLaiGhep1!=viTriLaiGhep2)
						break;
				}
				/*viTriNSTLaiGhep = ran.nextInt(soThamSo);*/
				double boThamSo1[] = new double[soThamSo];
				for(int i=0;i<soThamSo;++i)//con 1
				{
					boThamSo1[i]=(dsBoThamSo.get(dsViTriLaiGhep.get(viTriLaiGhep1))[i]
							+dsBoThamSo.get(dsViTriLaiGhep.get(viTriLaiGhep2))[i])/2;

				}
				dsBoThamSo.add(boThamSo1);
				double boThamSo2[] = new double[soThamSo];
				for(int i=0;i<soThamSo;++i)//con 2
				{
					/*boThamSo2[i]=Math.abs((dsBoThamSo.get(dsViTriLaiGhep.get(viTriLaiGhep1))[i]
									-dsBoThamSo.get(dsViTriLaiGhep.get(viTriLaiGhep2))[i])/2);*/
					/*boThamSo2[i]=(dsBoThamSo.get(dsViTriLaiGhep.get(viTriLaiGhep1))[i]
									-dsBoThamSo.get(dsViTriLaiGhep.get(viTriLaiGhep2))[i])/2;*/
					boThamSo2[i]=(dsBoThamSo.get(dsViTriLaiGhep.get(viTriLaiGhep1))[i]
							*dsBoThamSo.get(dsViTriLaiGhep.get(viTriLaiGhep2))[i])/((dsBoThamSo.get(dsViTriLaiGhep.get(viTriLaiGhep1))[i]
									+dsBoThamSo.get(dsViTriLaiGhep.get(viTriLaiGhep2))[i])/2);
				}
				dsBoThamSo.add(boThamSo2);
				dsViTriLaiGhep.remove(viTriLaiGhep1);
				if(viTriLaiGhep2==0)
					dsViTriLaiGhep.remove(viTriLaiGhep2);
				else
					dsViTriLaiGhep.remove(viTriLaiGhep2-1);

				soCaTheLaiGhep=soCaTheLaiGhep-2;
			}
		}

	}
	private void taiSanXuat() {
		/* Tái sản xuất-------------------------------*/
		/*ranTaiSanXuat = ranint.nextInt(n);

		for(int i=0;i<ranTaiSanXuat;++i)
		{
			double boThamSoTaiSX[]= new double[3];
			boThamSoTaiSX[0]=dsBoThamSo.get(i)[0];
			boThamSoTaiSX[1]=dsBoThamSo.get(i)[1];
			boThamSoTaiSX[2]=dsBoThamSo.get(i)[2];
			dsBoThamSoTaiSX.add(boThamSoTaiSX);
		}*/

	}
	private void sapXepDanhSachBoThamSoTheoDoUuTien(double[]uuTien,
			ArrayList<double[]> dsBoThamSo) {
		double[] dsTestBoThamSo = new double[uuTien.length];
		Double testUuTien=0.0;
		int size = uuTien.length;
		for(int i=0;i<size-1;++i)
		{
			for(int j=i+1;j<size;++j)
			{
				if(uuTien[i]>uuTien[j])
				{
					testUuTien = uuTien[i];
					uuTien[i]=uuTien[j];
					uuTien[j]=testUuTien;

					dsTestBoThamSo = dsBoThamSo.get(i);
					dsBoThamSo.set(i, dsBoThamSo.get(j));
					dsBoThamSo.set(j, dsTestBoThamSo);
				}
			}
		}

	}
	public ArrayList<double[]> getDsBoThamSoLuu1000() {
		return dsBoThamSoLuu1000;
	}
	public int getLl() {
		return ll;
	}
	public void setLl(int ll) {
		this.ll = ll;
	}
	
	
	
	


}
