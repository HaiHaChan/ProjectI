package ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import javax.swing.plaf.BorderUIResource;
import javax.swing.table.DefaultTableModel;

import Test2.Detaly;
import Test2.HamGA;
import connection.Connect;

public class UI extends JFrame {
	DefaultTableModel dtmdsBieuThuc,dtmdsBoXY,dtmKetQua,dtmBang;
	JTable tblBieuThuc,tblBoXY,tblKetQua,tblBang;
	JTextField txtSoLanLap,txtLaiGhep,txtDotBien,txtSoCaThe,txtKiVong;
	JButton btnGiai;
	Connect connect = new Connect();
	public ArrayList<ArrayList<List<Double>>> tapGiaTriXY = connect.getDsBoXY();
	public List<String> tapBieuThuc = connect.getDsBieuThuc();

	public String bieuThucDuocChon = "";
	public List<Double> boXYTuongUng = new ArrayList<Double>();

	public UI(String title){
		super(title);
		addControl();
		addEvent();
		hienThiDanhSachBieuThuc();
	}
	private void hienThiDanhSachBieuThuc() {
		connect.connect();
		connect.xayDungCacTapGiaTri();
		int i=1;
		for(String s:tapBieuThuc)
		{
			
			Vector<String>vec = new Vector<String>();
			vec.add(i+"");
			vec.add("y = " + s);
			dtmdsBieuThuc.addRow(vec);
			i++;
		}
	}
	private void addEvent() {
		tblBieuThuc.addMouseListener(new MouseListener() {

			public void mouseReleased(MouseEvent arg0) {}
			public void mousePressed(MouseEvent arg0) {}
			public void mouseExited(MouseEvent arg0) {}
			public void mouseEntered(MouseEvent arg0) {}
			public void mouseClicked(MouseEvent arg0) {
				int x = tblBieuThuc.getSelectedRow();
				if(x==-1)return;
				hienThiBoXY(x);
			}
		});

		btnGiai.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				int x = tblBieuThuc.getSelectedRow();
				if(x==-1)return;

				giaiVaHienThiKetQua(x);
			}
		});
	}

	protected void giaiVaHienThiKetQua(int x) {
		int kichThuocMang = tapGiaTriXY.get(x).size();
		double mangX[] = new double[kichThuocMang];
		double mangY[] = new double[kichThuocMang];

		for (int i = 0; i < kichThuocMang; i++) {
			mangX[i] =  tapGiaTriXY.get(x).get(i).get(0);
			mangY[i] =  tapGiaTriXY.get(x).get(i).get(1);
		}
		tapGiaTriXY.get(x).get(0).get(0);
		ArrayList<double[]>boThamSo;
		ArrayList<double[]>boThamSoLuu1000;
		HamGA GA = new HamGA(mangX, mangY, Double.parseDouble(txtLaiGhep.getText()), 
				Double.parseDouble(txtKiVong.getText()), 
				Integer.parseInt(txtSoCaThe.getText()), 
				Integer.parseInt(txtSoLanLap.getText()),
				Double.parseDouble(txtDotBien.getText()));
		boThamSo=GA.GAs(tapBieuThuc.get(x), x);
		boThamSoLuu1000=GA.getDsBoThamSoLuu1000();
		Detaly tinhKQ= new Detaly();
		
		double[] uuTien = new double[boThamSo.size()];
		for (int i = 0; i < uuTien.length; i++) {
		//	uuTien[i] = 1 - 1.0/(1+tinhKQ.detaly(mangX, mangY ,tapBieuThuc.get(x),boThamSo.get(i)));	
			uuTien[i] = tinhKQ.detaly(mangX, mangY ,tapBieuThuc.get(x),boThamSo.get(i));	
		}

		int row = tblKetQua.getRowCount();
		if(row!=0)
		{
			for (int i = row-1; i >= 0; i--) {
				dtmKetQua.removeRow(i);
			}
		}
		
		DecimalFormat df = new DecimalFormat("#.####");
		DecimalFormat df2 = new DecimalFormat("#.#############");
		for (int i = 0; i < uuTien.length; i++) {
			Vector<String> vec = new Vector<String>();
			String s="";
			
			for (int j = 0; j < boThamSo.get(0).length; j++) {
				s = s + "k["+(j+1)+"] = " + df.format(boThamSo.get(i)[j]) + "    ";
			}
			vec.add(s);
			vec.add(df2.format(uuTien[i])+"");
			dtmKetQua.addRow(vec);
		}
		
		
		int rowBang = tblBang.getRowCount();
		if(rowBang!=0)
		{
			for (int i = rowBang-1; i >= 0; i--) {
				dtmBang.removeRow(i);
			}
		}
		for (int i = 0; i <boThamSoLuu1000.size(); i++) {
			Vector<String> vecBang = new Vector<String>();
			String s="";
			
			for (int j = 0; j < boThamSoLuu1000.get(0).length; j++) {
				s = s + "k["+(j+1)+"] = " + df.format(boThamSoLuu1000.get(i)[j]) + "    ";
			}
			vecBang.add(10+10*i+"");
			vecBang.add(s);
			vecBang.add(df2.format(tinhKQ.detaly(mangX, mangY ,tapBieuThuc.get(x),boThamSoLuu1000.get(i)))+"");
			dtmBang.addRow(vecBang);
		}
	}

	protected void hienThiBoXY(int x) {

		int  k = tblBoXY.getRowCount();
		if(k!=0)
		{
			for(int i=k-1;i>=0;--i)
			{
				dtmdsBoXY.removeRow(i);
			}
		}

		/*for(List<Double> bo:tapGiaTriXY.get(x))
		{
			Vector<String>vec= new Vector<>();
			vec.add(bo.get(0)+"");
			vec.add(bo.get(1)+"");
			dtmdsBoXY.addRow(vec);
		}*/
		
		for (int i = 0; i < tapGiaTriXY.get(x).size(); i++) {
			Vector<String>vec= new Vector<>();
			vec.add(tapGiaTriXY.get(x).get(i).get(0)+"");
			vec.add(tapGiaTriXY.get(x).get(i).get(1)+"");
			dtmdsBoXY.addRow(vec);
		}
	}
	private void addControl() {

		Container con = getContentPane();
		con.setLayout(new BorderLayout());

		JPanel pndsBieuThuc = new JPanel();
		pndsBieuThuc.setLayout(new BorderLayout());
		con.add(pndsBieuThuc, BorderLayout.CENTER);
		TitledBorder boderBieuThuc = new TitledBorder(BorderFactory.createLineBorder(Color.BLACK),"Danh sách biểu thức");
		boderBieuThuc.setTitleColor(Color.BLUE);
		pndsBieuThuc.setBorder(boderBieuThuc);

		JPanel pndsBoXY = new JPanel();
		pndsBoXY.setLayout(new BorderLayout());
		pndsBoXY.setPreferredSize(new Dimension(200, 0));
		con.add(pndsBoXY, BorderLayout.EAST);
		TitledBorder boderBoXY = new TitledBorder(BorderFactory.createLineBorder(Color.BLACK),"Danh sách bộ XY");
		boderBoXY.setTitleColor(Color.BLUE);
		pndsBoXY.setBorder(boderBoXY);

		JPanel pnLoiGiai = new JPanel();
		pnLoiGiai.setLayout(new BorderLayout());
		pnLoiGiai.setPreferredSize(new Dimension(0,300));
		//pnLoiGiai.setBackground(Color.GREEN);
		con.add(pnLoiGiai, BorderLayout.SOUTH);
		TitledBorder boderLoiGiai = new TitledBorder(BorderFactory.createLineBorder(Color.BLUE),"Lời giải");
		boderLoiGiai.setTitleColor(Color.RED);
		pnLoiGiai.setBorder(boderLoiGiai);

		dtmdsBieuThuc = new DefaultTableModel();
		dtmdsBieuThuc.addColumn("STT");
		dtmdsBieuThuc.addColumn("Biểu thức");
		tblBieuThuc = new JTable(dtmdsBieuThuc);
		JScrollPane sc = new JScrollPane(tblBieuThuc,
				JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		pndsBieuThuc.add(sc, BorderLayout.CENTER);

		dtmdsBoXY = new DefaultTableModel();
		dtmdsBoXY.addColumn("X");
		dtmdsBoXY.addColumn("Y");
		tblBoXY = new JTable(dtmdsBoXY);
		JScrollPane sc2 = new JScrollPane(tblBoXY,
				JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		pndsBoXY.add(sc2, BorderLayout.CENTER);


		dtmKetQua = new DefaultTableModel();
		dtmKetQua.addColumn("Giá trị");
		dtmKetQua.addColumn("Độ ưu tiên");
		tblKetQua= new JTable(dtmKetQua);
		JScrollPane sc3 = new JScrollPane(tblKetQua,
				JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		pnLoiGiai.add(sc3, BorderLayout.CENTER);
		
		JPanel pnLoiGiaiOfLoiGiai= new JPanel();
		pnLoiGiaiOfLoiGiai.setLayout(new BorderLayout());
		pnLoiGiaiOfLoiGiai.setPreferredSize(new Dimension(0, 150));
		dtmBang = new DefaultTableModel();
		dtmBang.addColumn("Lần lặp");
		dtmBang.addColumn("Giá trị");
		dtmBang.addColumn("Độ ưu tien");
		tblBang = new JTable(dtmBang);
		JScrollPane scBang = new JScrollPane(tblBang,
				JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		pnLoiGiaiOfLoiGiai.add(scBang, BorderLayout.CENTER);
		pnLoiGiai.add(pnLoiGiaiOfLoiGiai, BorderLayout.SOUTH);
		
		JPanel pnThamSoVaLoiGiai = new JPanel();
		pnThamSoVaLoiGiai.setLayout(new BorderLayout());
		pnLoiGiaiOfLoiGiai.add(pnThamSoVaLoiGiai, BorderLayout.SOUTH);
		btnGiai = new JButton("Giai");
		pnThamSoVaLoiGiai.add(btnGiai,BorderLayout.SOUTH);
		
		JPanel pnThamSo = new JPanel();
		pnThamSo.setLayout(new GridLayout(0, 5));
		pnThamSoVaLoiGiai.add(pnThamSo, BorderLayout.CENTER);
		
		JPanel pnSoCaThe = new JPanel();
		pnSoCaThe.setLayout(new FlowLayout());
		JLabel lblSoCaThe = new JLabel("Số cá thể: ");
		txtSoCaThe = new JTextField(5);
		txtSoCaThe.setText("100");
		pnSoCaThe.add(lblSoCaThe);
		pnSoCaThe.add(txtSoCaThe);
		pnThamSo.add(pnSoCaThe);
		
		JPanel pnKiVong = new JPanel();
		pnKiVong.setLayout(new FlowLayout());
		JLabel lblKiVong = new JLabel("Kỳ vọng: ");
		txtKiVong = new JTextField(5);
		txtKiVong.setText("0.1");
		pnKiVong.add(lblKiVong);
		pnKiVong.add(txtKiVong);
		pnThamSo.add(pnKiVong);
		
		JPanel pnLaiGhep = new JPanel();
		pnLaiGhep.setLayout(new FlowLayout());
		JLabel lblLaiGhep = new JLabel("XS l.ghép: ");
		txtLaiGhep = new JTextField(5);
		txtLaiGhep.setText("0.5");
		pnLaiGhep.add(lblLaiGhep);
		pnLaiGhep.add(txtLaiGhep);
		pnThamSo.add(pnLaiGhep);
		
		JPanel pnDotBien = new JPanel();
		pnDotBien.setLayout(new FlowLayout());
		JLabel lblDotBien = new JLabel("XS đ.biến: ");
		txtDotBien = new JTextField(5);
		txtDotBien.setText("0.1");
		pnDotBien.add(lblDotBien);
		pnDotBien.add(txtDotBien);
		pnThamSo.add(pnDotBien);
		
		JPanel pnSoLanLap = new JPanel();
		pnSoCaThe.setLayout(new FlowLayout());
		JLabel lblSoLanLap = new JLabel("Lặp: ");
		txtSoLanLap = new JTextField(5);
		txtSoLanLap.setText("100");
		pnSoLanLap.add(lblSoLanLap);
		pnSoLanLap.add(txtSoLanLap);
		pnThamSo.add(pnSoLanLap);

	}

	public void showWindows(){
		this.setSize(700, 500);
		this.setResizable(false);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}
}
