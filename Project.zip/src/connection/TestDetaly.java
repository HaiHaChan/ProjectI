package connection;

import Test2.Detaly;

public class TestDetaly {

	public static void main(String[] args) {

		   String sMath="k_{1}*(x+273.1)^0.5+k_{2}";
	        Detaly tinh = new Detaly();
	        double[] x = {-21.0,0.0,100,182,302};
	        double[] y={12.9,14.0,18.6,22.2,26.8};
	        double[] k = {17.8,116};
	        double uutien = tinh.detaly(x, y, sMath, k);
	        System.out.println(uutien);
	}

}
