package connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Connect {
	private final String className = "com.mysql.jdbc.Driver";
	private final String url = "jdbc:mysql://localhost:3306/project_1";
	private final String user = "root";
	private final String password = "";
	private String table1 = "parameters_2";
	private String table2 = "reference_relation";
	
	private Connection connection;
	
	//public static List<Double> dsX = new ArrayList<Double>();
	public static ArrayList<ArrayList<List<Double>>> tapGiaTriXY = new ArrayList<ArrayList<List<Double>>>();
	public static List<String> tapBieuThuc = new ArrayList<String>() ;
	
	public void connect()
	{
		try 
		{
			Class.forName(className);
			connection =  DriverManager.getConnection(url, user, password);
			System.out.println("Connect success");
			
		} catch (ClassNotFoundException e) 
		{
			System.out.println("Class not found");
			
		} catch (SQLException e) 
		{
			System.out.println("Error Connect");
		}
		
	}
	
	public void xayDungCacTapGiaTri()
	{
		ResultSet rs = null;
		String sqlCommand = "select * from " + table1; // Lấy dữ liệu từ bảng parameter
		//java.sql.Statement st  ;
		
		try {
			java.sql.Statement st = connection.createStatement();
			rs= st.executeQuery(sqlCommand);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		ArrayList<List<Double>> tapCacCapGiaTriXYUngVoiMoiBieuThuc = new ArrayList<List<Double>>();
		int bieuThucTuongUng = 1;
		
		try {
			while (rs.next()) {
				List<Double> capGiaTriXY = new ArrayList<Double>();
				capGiaTriXY.add(rs.getDouble(3));
				capGiaTriXY.add(rs.getDouble(4));
				if (rs.getInt(2) == bieuThucTuongUng) {
					tapCacCapGiaTriXYUngVoiMoiBieuThuc.add(capGiaTriXY);
				}else{
					tapGiaTriXY.add(tapCacCapGiaTriXYUngVoiMoiBieuThuc);
					bieuThucTuongUng = rs.getInt(2);
					tapCacCapGiaTriXYUngVoiMoiBieuThuc = new ArrayList<List<Double>>();
					tapCacCapGiaTriXYUngVoiMoiBieuThuc.add(capGiaTriXY);
				}
			}
			tapGiaTriXY.add(tapCacCapGiaTriXYUngVoiMoiBieuThuc);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		ResultSet rs2 = null;
		String sqlCommand2 = "select * from " + table2; // Lấy dữ liệu từ bảng reference_relation
		//java.sql.Statement st  ;
		
		try {
			java.sql.Statement st = connection.createStatement();
			rs2= st.executeQuery(sqlCommand2);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			while (rs2.next()) {
				tapBieuThuc.add(rs2.getString(2));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public List<String> getDsBieuThuc(){
		return tapBieuThuc;
	}
	
	public ArrayList<ArrayList<List<Double>>> getDsBoXY() {
		return tapGiaTriXY;
	}
}
